# ClinPharm AI Trainer

Klinik farmakologiyani o'qitish uchun sun'iy intellekt asosidagi onlayn tренажёр платформа.

## Loyiha haqida

ClinPharm AI Trainer — talabalar, rezidentlar va shifokorlar uchun klinik vaziyatlar asosida ratsional dori tanlashni o'rgatuvchi web-platforma.

## Imkoniyatlar

- **3 ta rol**: Admin, O'qituvchi, Talaba
- **Virtual bemor keyslari** — pnevmoniya, kardiologiya, gastroenterologiya va boshqalar
- **Dori tanlash moduli** — dori nomi, doza, yo'nalish, davomiylik
- **Avtomatik baholash** — 10 mezon bo'yicha ball
- **AI fikr-mulohaza** — xatolar tahlili va tavsiyalar
- **Hisobotlar va statistika** — talaba va guruh natijalari
- **O'zbek tilida** interfeys

## Texnologiyalar

| Qism | Texnologiya |
|------|-------------|
| Frontend | React + Vite + TypeScript |
| Backend | Express.js (Node.js) |
| Ma'lumotlar bazasi | PostgreSQL + Drizzle ORM |
| UI | Tailwind CSS + shadcn/ui |
| API | OpenAPI 3.1 + codegen |
| Package manager | pnpm workspaces |

## Fayl tuzilmasi

```
clinpharm/
├── artifacts/
│   ├── api-server/          # Express backend
│   │   └── src/
│   │       ├── routes/      # API yo'nalishlari
│   │       └── lib/         # Auth yordamchi funksiyalar
│   └── clinpharm/           # React frontend
│       └── src/
│           ├── pages/       # Sahifalar
│           ├── components/  # UI komponentlar
│           └── hooks/       # React hooks
├── lib/
│   ├── api-spec/            # OpenAPI spec
│   ├── api-client-react/    # Generatsiya qilingan React hooks
│   ├── api-zod/             # Generatsiya qilingan Zod schemalar
│   └── db/                  # Drizzle ORM schema
└── scripts/                 # Yordamchi skriptlar (seeding)
```

## O'rnatish va ishga tushurish

### Talablar

- Node.js 20+
- pnpm 9+
- PostgreSQL ma'lumotlar bazasi

### 1. Loyihani yuklab oling

```bash
git clone https://github.com/sizning-username/clinpharm.git
cd clinpharm
```

### 2. Muhit o'zgaruvchilarini sozlang

`.env` fayl yarating:

```env
DATABASE_URL=postgresql://user:password@localhost:5432/clinpharm
PORT=8080
```

### 3. Bog'liqliklarni o'rnating

```bash
pnpm install
```

### 4. Ma'lumotlar bazasini tayyorlang

```bash
pnpm --filter @workspace/db run push
pnpm --filter @workspace/scripts run seed
```

### 5. Ishga tushiring

Backend:
```bash
pnpm --filter @workspace/api-server run dev
```

Frontend (alohida terminalda):
```bash
pnpm --filter @workspace/clinpharm run dev
```

## Kirish ma'lumotlari (demo)

| Rol | Email | Parol |
|-----|-------|-------|
| Admin | admin@clinpharm.uz | admin123 |
| O'qituvchi | teacher@clinpharm.uz | teacher123 |
| Talaba | student@clinpharm.uz | student123 |

## API

API serveri `/api` yo'li orqali ishlaydi:

- `POST /api/auth/login` — Tizimga kirish
- `POST /api/auth/register` — Ro'yxatdan o'tish
- `GET /api/cases` — Keyslar ro'yxati
- `POST /api/cases/:id/submit` — Javob topshirish
- `GET /api/analytics/overview` — Umumiy statistika

To'liq API dokumentatsiyasi: `lib/api-spec/openapi.yaml`

## Litsenziya

MIT
