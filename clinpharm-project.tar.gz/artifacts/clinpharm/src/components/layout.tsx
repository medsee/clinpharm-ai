import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { 
  Stethoscope, 
  LayoutDashboard, 
  FileText, 
  CheckCircle, 
  Users, 
  BarChart, 
  LogOut, 
  Menu,
  X
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Button } from "./ui/button";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  if (!user) return <>{children}</>;

  const navigation = [
    { name: "Asosiy", href: "/", icon: LayoutDashboard, roles: ["student", "teacher", "admin"] },
    { name: "Keyslar", href: "/cases", icon: FileText, roles: ["student", "teacher", "admin"] },
    { name: "Natijalarim", href: "/results", icon: CheckCircle, roles: ["student"] },
    { name: "Barcha Natijalar", href: "/results", icon: CheckCircle, roles: ["teacher", "admin"] },
    { name: "Yangi Keys", href: "/teacher/cases/new", icon: Stethoscope, roles: ["teacher", "admin"] },
    { name: "Foydalanuvchilar", href: "/admin/users", icon: Users, roles: ["admin"] },
    { name: "Tahlillar", href: "/analytics", icon: BarChart, roles: ["teacher", "admin"] },
  ];

  const allowedNav = navigation.filter(item => item.roles.includes(user.role));

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-72 bg-white border-r border-slate-200 z-20">
        <div className="p-6 flex items-center gap-3">
          <div className="bg-primary/10 p-2 rounded-xl">
            <Stethoscope className="h-7 w-7 text-primary" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-slate-900">ClinPharm AI</span>
        </div>
        
        <div className="px-6 pb-4">
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
            <p className="font-semibold text-sm text-slate-900">{user.name}</p>
            <p className="text-xs text-slate-500 mt-1 capitalize">{user.role}</p>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1 mt-4">
          {allowedNav.map((item) => {
            const isActive = location === item.href || (location.startsWith(item.href) && item.href !== '/');
            return (
              <Link 
                key={item.name} 
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                )}
              >
                <item.icon className={cn("h-5 w-5", isActive ? "text-primary-foreground" : "text-slate-400")} />
                {item.name}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 mt-auto border-t border-slate-100">
          <button 
            onClick={() => logout.mutate()}
            className="flex w-full items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="h-5 w-5" />
            Chiqish
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 z-30">
        <div className="flex items-center gap-2">
          <Stethoscope className="h-6 w-6 text-primary" />
          <span className="font-display font-bold text-lg">ClinPharm</span>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 text-slate-600">
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-20 bg-white pt-16">
          <nav className="p-4 space-y-2">
            {allowedNav.map((item) => (
              <Link 
                key={item.name} 
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-4 rounded-xl text-base font-medium",
                  location === item.href ? "bg-primary text-white" : "text-slate-600 bg-slate-50"
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.name}
              </Link>
            ))}
            <button 
              onClick={() => logout.mutate()}
              className="flex w-full items-center gap-3 px-4 py-4 rounded-xl text-base font-medium text-destructive bg-destructive/10"
            >
              <LogOut className="h-5 w-5" />
              Chiqish
            </button>
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-x-hidden md:pt-0 pt-16 relative">
        <div className="absolute top-0 left-0 right-0 h-64 bg-primary/5 -z-10" />
        <div className="p-4 md:p-8 max-w-7xl mx-auto page-enter">
          {children}
        </div>
      </main>
    </div>
  );
}
