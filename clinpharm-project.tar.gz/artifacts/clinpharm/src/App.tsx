import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { Layout } from "@/components/layout";

import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import CasesList from "@/pages/cases/list";
import SolveCase from "@/pages/cases/solve";
import CaseEditor from "@/pages/cases/editor";
import SubmissionsList from "@/pages/submissions/list";
import SubmissionDetail from "@/pages/submissions/detail";
import Analytics from "@/pages/analytics";
import AdminUsers from "@/pages/admin/users";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, ...rest }: any) {
  return (
    <Layout>
      <Component {...rest} />
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />

      <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/cases" component={() => <ProtectedRoute component={CasesList} />} />
      <Route path="/cases/:id" component={() => <ProtectedRoute component={SolveCase} />} />

      <Route path="/teacher/cases/new" component={() => <ProtectedRoute component={CaseEditor} />} />
      <Route path="/teacher/cases/:id/edit" component={() => <ProtectedRoute component={CaseEditor} />} />

      <Route path="/results" component={() => <ProtectedRoute component={SubmissionsList} />} />
      <Route path="/results/:id" component={() => <ProtectedRoute component={SubmissionDetail} />} />

      <Route path="/analytics" component={() => <ProtectedRoute component={Analytics} />} />
      <Route path="/admin/users" component={() => <ProtectedRoute component={AdminUsers} />} />

      <Route component={() => (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-6xl font-bold text-slate-200">404</h1>
            <p className="text-slate-500 mt-2">Sahifa topilmadi</p>
          </div>
        </div>
      )} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
