import { createContext, useContext, useEffect } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useGetMe, 
  useLogin, 
  useRegister,
  useLogout,
  type User,
  type LoginRequest,
  type RegisterRequest
} from "@workspace/api-client-react";
import { useToast } from "./use-toast";

type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  login: ReturnType<typeof useLogin>;
  register: ReturnType<typeof useRegister>;
  logout: ReturnType<typeof useLogout>;
};

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Ensure token is attached to fetch calls
  useEffect(() => {
    const originalFetch = window.fetch;
    window.fetch = async (input, init) => {
      const token = localStorage.getItem('clinpharm_token');
      if (token && typeof input === 'string' && input.startsWith('/api')) {
        init = init || {};
        init.headers = {
          ...init.headers,
          Authorization: `Bearer ${token}`
        };
      }
      const response = await originalFetch(input, init);
      if (response.status === 401 && !input.includes('/auth/login')) {
        localStorage.removeItem('clinpharm_token');
        queryClient.setQueryData([`/api/auth/me`], null);
        setLocation('/login');
      }
      return response;
    };
    return () => { window.fetch = originalFetch; };
  }, [queryClient, setLocation]);

  const { data: user, isLoading } = useGetMe({
    query: {
      retry: false,
      staleTime: Infinity,
    }
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (data) => {
        localStorage.setItem('clinpharm_token', data.token);
        queryClient.setQueryData([`/api/auth/me`], data.user);
        toast({ title: "Muvaffaqiyatli", description: "Tizimga kirdingiz" });
        setLocation("/");
      },
      onError: (err: any) => {
        toast({ 
          title: "Xatolik", 
          description: err.message || "Email yoki parol noto'g'ri", 
          variant: "destructive" 
        });
      }
    }
  });

  const registerMutation = useRegister({
    mutation: {
      onSuccess: (data) => {
        localStorage.setItem('clinpharm_token', data.token);
        queryClient.setQueryData([`/api/auth/me`], data.user);
        toast({ title: "Muvaffaqiyatli", description: "Ro'yxatdan o'tdingiz" });
        setLocation("/");
      },
      onError: (err: any) => {
        toast({ 
          title: "Xatolik", 
          description: err.message || "Ro'yxatdan o'tishda xatolik yuz berdi", 
          variant: "destructive" 
        });
      }
    }
  });

  const logoutMutation = useLogout({
    mutation: {
      onSettled: () => {
        localStorage.removeItem('clinpharm_token');
        queryClient.setQueryData([`/api/auth/me`], null);
        queryClient.clear();
        setLocation("/login");
      }
    }
  });

  return (
    <AuthContext.Provider value={{ 
      user: user || null, 
      isLoading, 
      login: loginMutation, 
      register: registerMutation, 
      logout: logoutMutation 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};
