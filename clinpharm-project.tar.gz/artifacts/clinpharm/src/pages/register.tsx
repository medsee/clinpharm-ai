import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { RegisterRequestRole } from "@workspace/api-client-react";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<RegisterRequestRole>("student");
  const { register } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    register.mutate({ data: { name, email, password, role } });
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-slate-50 p-4 relative">
      <img 
        src={`${import.meta.env.BASE_URL}images/medical-bg.png`} 
        alt="Background" 
        className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none"
      />
      
      <Card className="w-full max-w-lg p-8 shadow-2xl relative z-10 glass">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-display font-bold text-slate-900">Ro'yxatdan o'tish</h2>
          <p className="text-slate-500 mt-2">Yangi hisob yarating</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="name">F.I.SH.</Label>
            <Input 
              id="name" 
              placeholder="Aliyev Vali"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input 
              id="email" 
              type="email" 
              placeholder="talaba@tma.uz"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="password">Parol</Label>
            <Input 
              id="password" 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Rol</Label>
            <div className="grid grid-cols-2 gap-4">
              <label className={`
                flex items-center justify-center p-3 rounded-xl border-2 cursor-pointer transition-all
                ${role === 'student' ? 'border-primary bg-primary/5 text-primary font-semibold' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}
              `}>
                <input 
                  type="radio" 
                  name="role" 
                  value="student" 
                  checked={role === 'student'} 
                  onChange={(e) => setRole(e.target.value as any)}
                  className="sr-only"
                />
                Talaba
              </label>
              <label className={`
                flex items-center justify-center p-3 rounded-xl border-2 cursor-pointer transition-all
                ${role === 'teacher' ? 'border-primary bg-primary/5 text-primary font-semibold' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}
              `}>
                <input 
                  type="radio" 
                  name="role" 
                  value="teacher" 
                  checked={role === 'teacher'} 
                  onChange={(e) => setRole(e.target.value as any)}
                  className="sr-only"
                />
                O'qituvchi
              </label>
            </div>
          </div>

          <Button type="submit" className="w-full h-12 mt-4" isLoading={register.isPending}>
            Ro'yxatdan o'tish
          </Button>
        </form>

        <p className="text-center mt-6 text-sm text-slate-600">
          Hisobingiz bormi?{' '}
          <Link href="/login" className="font-semibold text-primary hover:underline">
            Tizimga kirish
          </Link>
        </p>
      </Card>
    </div>
  );
}
