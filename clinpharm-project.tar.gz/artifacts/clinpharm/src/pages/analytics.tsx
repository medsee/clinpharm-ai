import { useGetAnalyticsOverview, useListSubmissions } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useEffect } from "react";

const COLORS = ["#ef4444", "#f97316", "#22c55e", "#3b82f6"];

export default function Analytics() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user && !["teacher", "admin"].includes(user.role)) {
      setLocation("/");
    }
  }, [user]);

  const { data: analytics, isLoading } = useGetAnalyticsOverview();
  const { data: submissions } = useListSubmissions({});

  if (isLoading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-64 bg-slate-200 rounded" />
        <div className="grid grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="h-28 bg-slate-200 rounded-xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Tahlil va hisobotlar</h1>
        <p className="text-slate-500 mt-1">Platform faoliyatining umumiy ko'rinishi</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Jami talabalar", value: analytics?.totalStudents || 0, color: "bg-blue-50 text-blue-700" },
          { label: "Jami keyslar", value: analytics?.totalCases || 0, color: "bg-indigo-50 text-indigo-700" },
          { label: "Jami topshiriqlar", value: analytics?.totalSubmissions || 0, color: "bg-teal-50 text-teal-700" },
          { label: "O'rtacha ball", value: `${analytics?.averageScore?.toFixed(1) || 0}%`, color: "bg-emerald-50 text-emerald-700" },
        ].map((stat, i) => (
          <Card key={i}>
            <CardContent className={`p-6 rounded-xl ${stat.color}`}>
              <p className="text-sm font-medium opacity-70">{stat.label}</p>
              <p className="text-3xl font-bold mt-1">{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Ball taqsimoti</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={analytics?.scoreDistribution || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="range" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#0ea5e9" radius={[6, 6, 0, 0]} name="Talabalar soni" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Eng ko'p uchraydigan xatolar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analytics?.topMistakeAreas?.length ? analytics.topMistakeAreas.map((mistake, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
                  <span className="w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                    {i + 1}
                  </span>
                  <span className="text-sm text-slate-700">{mistake}</span>
                </div>
              )) : (
                <p className="text-slate-400 text-center py-8">Hali ma'lumot yo'q</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>So'nggi topshiriqlar</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-slate-500">
                  <th className="pb-3 pr-4">Talaba</th>
                  <th className="pb-3 pr-4">Keys</th>
                  <th className="pb-3 pr-4">Ball</th>
                  <th className="pb-3">Sana</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {submissions?.slice(0, 10).map(sub => (
                  <tr key={sub.id} className="hover:bg-slate-50">
                    <td className="py-3 pr-4 font-medium text-slate-900">{sub.studentName}</td>
                    <td className="py-3 pr-4 text-slate-600 max-w-[200px] truncate">{sub.caseTitle}</td>
                    <td className="py-3 pr-4">
                      <Badge variant={sub.percentage >= 80 ? "default" : sub.percentage >= 50 ? "secondary" : "destructive"}>
                        {sub.percentage}%
                      </Badge>
                    </td>
                    <td className="py-3 text-slate-500">{new Date(sub.submittedAt).toLocaleDateString('uz-UZ')}</td>
                  </tr>
                ))}
                {!submissions?.length && (
                  <tr><td colSpan={4} className="py-8 text-center text-slate-400">Topshiriqlar yo'q</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
