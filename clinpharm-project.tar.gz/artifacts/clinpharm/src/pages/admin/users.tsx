import { useListUsers, useUpdateUser } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";

const roleColors: Record<string, string> = {
  admin: "bg-purple-100 text-purple-700",
  teacher: "bg-blue-100 text-blue-700",
  student: "bg-green-100 text-green-700",
};

const roleLabels: Record<string, string> = {
  admin: "Admin",
  teacher: "O'qituvchi",
  student: "Talaba",
};

export default function AdminUsers() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (user && user.role !== "admin") {
      setLocation("/");
    }
  }, [user]);

  const { data: users, isLoading } = useListUsers();
  const updateUser = useUpdateUser({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      }
    }
  });

  const handleRoleChange = (userId: number, newRole: "student" | "teacher" | "admin") => {
    updateUser.mutate({ id: userId, data: { role: newRole } });
  };

  if (isLoading) {
    return <div className="animate-pulse space-y-4">{[...Array(5)].map((_, i) => <div key={i} className="h-16 bg-slate-200 rounded-xl" />)}</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Foydalanuvchilarni boshqarish</h1>
        <p className="text-slate-500 mt-1">Barcha foydalanuvchilar va ularning rollari</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Foydalanuvchilar ({users?.length || 0})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left text-slate-500">
                  <th className="pb-3 pr-4">Ism</th>
                  <th className="pb-3 pr-4">Email</th>
                  <th className="pb-3 pr-4">Rol</th>
                  <th className="pb-3 pr-4">Qo'shilgan</th>
                  <th className="pb-3">Rolni o'zgartirish</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {users?.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="py-4 pr-4 font-medium text-slate-900">{u.name}</td>
                    <td className="py-4 pr-4 text-slate-600">{u.email}</td>
                    <td className="py-4 pr-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${roleColors[u.role]}`}>
                        {roleLabels[u.role]}
                      </span>
                    </td>
                    <td className="py-4 pr-4 text-slate-500">
                      {new Date(u.createdAt).toLocaleDateString('uz-UZ')}
                    </td>
                    <td className="py-4">
                      <div className="flex gap-2">
                        {(["student", "teacher", "admin"] as const).filter(r => r !== u.role).map(role => (
                          <Button
                            key={role}
                            size="sm"
                            variant="outline"
                            onClick={() => handleRoleChange(u.id, role)}
                            className="text-xs"
                          >
                            {roleLabels[role]}
                          </Button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
