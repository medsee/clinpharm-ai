import { useState } from "react";
import { Link } from "wouter";
import { useListCases } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, Stethoscope, Plus } from "lucide-react";

export default function CasesList() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const { data: cases, isLoading } = useListCases();

  const filteredCases = cases?.filter(c => 
    c.title.toLowerCase().includes(search.toLowerCase()) || 
    c.specialty.toLowerCase().includes(search.toLowerCase())
  );

  const getDifficultyColor = (diff: string) => {
    switch(diff) {
      case 'easy': return 'success';
      case 'medium': return 'warning';
      case 'hard': return 'destructive';
      default: return 'default';
    }
  };

  const getDifficultyLabel = (diff: string) => {
    switch(diff) {
      case 'easy': return 'Oson';
      case 'medium': return "O'rta";
      case 'hard': return 'Qiyin';
      default: return diff;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">Klinik Keyslar</h1>
          <p className="text-slate-500 mt-1">Bemorlar holatini tahlil qiling va davolash rejasini tuzing</p>
        </div>
        {(user?.role === 'teacher' || user?.role === 'admin') && (
          <Link href="/teacher/cases/new">
            <Button className="gap-2"><Plus className="h-4 w-4" /> Yangi keys</Button>
          </Link>
        )}
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
        <Input 
          placeholder="Keys yoki mutaxassislik bo'yicha qidiruv..." 
          className="pl-10 h-12 rounded-xl"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="h-48 bg-slate-200 animate-pulse rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCases?.map((c) => (
            <Card key={c.id} className="group hover:-translate-y-1 transition-all duration-300">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-primary/10 p-3 rounded-xl text-primary">
                    <Stethoscope className="h-6 w-6" />
                  </div>
                  <Badge variant={getDifficultyColor(c.difficulty) as any}>
                    {getDifficultyLabel(c.difficulty)}
                  </Badge>
                </div>
                
                <h3 className="text-xl font-bold text-slate-900 mb-2 line-clamp-2">{c.title}</h3>
                
                <div className="mt-auto space-y-3 pt-4">
                  <div className="flex items-center text-sm text-slate-600">
                    <span className="w-24 text-slate-400">Mutaxassislik:</span>
                    <span className="font-medium">{c.specialty}</span>
                  </div>
                  <div className="flex items-center text-sm text-slate-600">
                    <span className="w-24 text-slate-400">Mavzu:</span>
                    <span className="font-medium truncate">{c.topic}</span>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex gap-2">
                  <Link href={`/cases/${c.id}`} className="flex-1">
                    <Button className="w-full" variant={user?.role === 'student' ? 'default' : 'outline'}>
                      Ko'rish
                    </Button>
                  </Link>
                  {(user?.role === 'teacher' || user?.role === 'admin') && (
                    <Link href={`/teacher/cases/${c.id}/edit`}>
                      <Button variant="secondary" size="icon">
                        <Stethoscope className="h-4 w-4" />
                      </Button>
                    </Link>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
          {filteredCases?.length === 0 && (
            <div className="col-span-full py-12 text-center text-slate-500">
              Hech qanday keys topilmadi.
            </div>
          )}
        </div>
      )}
    </div>
  );
}
