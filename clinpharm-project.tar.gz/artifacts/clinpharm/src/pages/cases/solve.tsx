import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useGetCase, useSubmitAnswer } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Plus, Trash2, Activity, AlertCircle, FileText, ClipboardList } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function SolveCase() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const caseId = parseInt(id || "0");
  
  const { data: clinicalCase, isLoading } = useGetCase(caseId);
  const submitMutation = useSubmitAnswer();

  const [activeTab, setActiveTab] = useState("passport");
  
  // Form State
  const [drugs, setDrugs] = useState([{ drugName: '', dose: '', frequency: '', route: '', duration: '', rationale: '' }]);
  const [monitoringPlan, setMonitoringPlan] = useState("");
  const [sideEffectPrevention, setSideEffectPrevention] = useState("");
  const [clinicalRationale, setClinicalRationale] = useState("");

  if (isLoading) return <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!clinicalCase) return <div>Case not found</div>;

  const patient = clinicalCase.patientInfo;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Filter empty drugs
    const validDrugs = drugs.filter(d => d.drugName.trim() !== '');
    if (validDrugs.length === 0) {
      toast({ title: "Xatolik", description: "Kamida bitta dori kiritish kerak", variant: "destructive" });
      return;
    }

    submitMutation.mutate({
      id: caseId,
      data: {
        drugs: validDrugs,
        monitoringPlan,
        sideEffectPrevention,
        clinicalRationale
      }
    }, {
      onSuccess: (result) => {
        // Save result to location state to display in next page
        toast({ title: "Muvaffaqiyatli topshirildi" });
        setLocation(`/results/${result.id}`);
      }
    });
  };

  const tabs = [
    { id: "passport", label: "Pasport qismi", icon: FileText },
    { id: "history", label: "Anamnez", icon: ClipboardList },
    { id: "status", label: "Obyektiv Holat", icon: Activity },
    { id: "treatment", label: "Davolash Rejasi", icon: AlertCircle },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{clinicalCase.title}</h1>
        <p className="text-slate-500 mt-1">{clinicalCase.topic} • {clinicalCase.specialty}</p>
      </div>

      <div className="flex overflow-x-auto pb-2 border-b border-slate-200 hide-scrollbar gap-6">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 pb-3 font-medium whitespace-nowrap border-b-2 transition-colors ${
              activeTab === tab.id ? "border-primary text-primary" : "border-transparent text-slate-500 hover:text-slate-700"
            }`}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 min-h-[400px]">
        {activeTab === "passport" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-12">
            <InfoItem label="Yoshi" value={`${patient.age} yosh`} />
            <InfoItem label="Jinsi" value={patient.gender === 'male' ? 'Erkak' : 'Ayol'} />
            <div className="col-span-full">
              <InfoItem label="Asosiy shikoyatlari" value={patient.mainComplaint} />
            </div>
            <InfoItem label="Og'irlik darajasi" value={
              patient.severityLevel === 'mild' ? 'Yengil' : 
              patient.severityLevel === 'moderate' ? "O'rta" : "Og'ir"
            } />
            {patient.gender === 'female' && (
              <>
                <InfoItem label="Homiladorlik" value={patient.isPregnant ? 'Ha' : "Yo'q"} />
                <InfoItem label="Emizish" value={patient.isLactating ? 'Ha' : "Yo'q"} />
              </>
            )}
          </div>
        )}

        {activeTab === "history" && (
          <div className="space-y-6">
            <InfoItem label="Kasallik anamnezi (Morbi)" value={patient.anamnesis} />
            <InfoItem label="Yondosh kasalliklar" value={patient.comorbidities || "Yo'q"} />
            <InfoItem label="Allergik anamnez" value={patient.allergyHistory || "Aniqlanmadi"} />
            <InfoItem label="Hozirda qabul qilayotgan dorilari" value={patient.currentMedications || "Yo'q"} />
          </div>
        )}

        {activeTab === "status" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <InfoItem label="Jigar holati" value={patient.liverStatus} />
              <InfoItem label="Buyrak holati" value={patient.kidneyStatus} />
            </div>
            <InfoItem label="Laboratoriya tekshiruvlari" value={patient.labResults || "Ma'lumot yo'q"} />
            <InfoItem label="Instrumental tekshiruvlar" value={patient.instrumentalResults || "Ma'lumot yo'q"} />
          </div>
        )}

        {activeTab === "treatment" && (
          <form onSubmit={handleSubmit} className="space-y-8 animate-in fade-in">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-bold">Farmakoterapiya</h3>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setDrugs([...drugs, { drugName: '', dose: '', frequency: '', route: '', duration: '', rationale: '' }])}
                >
                  <Plus className="h-4 w-4 mr-2" /> Dori qo'shish
                </Button>
              </div>

              {drugs.map((drug, index) => (
                <Card key={index} className="bg-slate-50 border-slate-200">
                  <CardContent className="p-4 relative">
                    {drugs.length > 1 && (
                      <button 
                        type="button"
                        onClick={() => setDrugs(drugs.filter((_, i) => i !== index))}
                        className="absolute top-4 right-4 text-red-500 hover:bg-red-50 p-1 rounded"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-2">
                      <div className="space-y-1">
                        <Label>Dori nomi (XPN)</Label>
                        <Input 
                          value={drug.drugName} 
                          onChange={(e) => {
                            const newDrugs = [...drugs];
                            newDrugs[index].drugName = e.target.value;
                            setDrugs(newDrugs);
                          }} 
                          required 
                          placeholder="Masalan: Amoxicillin"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label>Doza</Label>
                        <Input 
                          value={drug.dose} 
                          onChange={(e) => {
                            const newDrugs = [...drugs];
                            newDrugs[index].dose = e.target.value;
                            setDrugs(newDrugs);
                          }} 
                          required 
                          placeholder="500 mg"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label>Chastota</Label>
                        <Input 
                          value={drug.frequency} 
                          onChange={(e) => {
                            const newDrugs = [...drugs];
                            newDrugs[index].frequency = e.target.value;
                            setDrugs(newDrugs);
                          }} 
                          required 
                          placeholder="Kuniga 3 mahal"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label>Yo'nalish</Label>
                        <Input 
                          value={drug.route} 
                          onChange={(e) => {
                            const newDrugs = [...drugs];
                            newDrugs[index].route = e.target.value;
                            setDrugs(newDrugs);
                          }} 
                          required 
                          placeholder="Per os"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label>Davomiyligi</Label>
                        <Input 
                          value={drug.duration} 
                          onChange={(e) => {
                            const newDrugs = [...drugs];
                            newDrugs[index].duration = e.target.value;
                            setDrugs(newDrugs);
                          }} 
                          required 
                          placeholder="7 kun"
                        />
                      </div>
                      <div className="col-span-1 lg:col-span-3 space-y-1">
                        <Label>Asoslash (nima uchun bu dori?)</Label>
                        <Input 
                          value={drug.rationale} 
                          onChange={(e) => {
                            const newDrugs = [...drugs];
                            newDrugs[index].rationale = e.target.value;
                            setDrugs(newDrugs);
                          }} 
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-200">
              <h3 className="text-lg font-bold">Qo'shimcha ko'rsatmalar</h3>
              
              <div className="space-y-2">
                <Label>Klinik farmakologik asoslash</Label>
                <Textarea 
                  value={clinicalRationale}
                  onChange={e => setClinicalRationale(e.target.value)}
                  placeholder="Tanlangan dorilar guruhining ushbu holatdagi afzalliklari..."
                />
              </div>

              <div className="space-y-2">
                <Label>Monitoring rejasi (Samaradorlik va xavfsizlik)</Label>
                <Textarea 
                  value={monitoringPlan}
                  onChange={e => setMonitoringPlan(e.target.value)}
                  placeholder="Qaysi ko'rsatkichlarni qachon tekshirish kerak?"
                />
              </div>

              <div className="space-y-2">
                <Label>Nojo'ya ta'sirlarni oldini olish</Label>
                <Textarea 
                  value={sideEffectPrevention}
                  onChange={e => setSideEffectPrevention(e.target.value)}
                  placeholder="Kutilishi mumkin bo'lgan nojo'ya ta'sirlar va ularning profilaktikasi"
                />
              </div>
            </div>

            <div className="pt-6 flex justify-end">
              <Button type="submit" size="lg" className="px-12" isLoading={submitMutation.isPending}>
                Topshirish va Baholash
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

function InfoItem({ label, value }: { label: string, value: string }) {
  return (
    <div>
      <p className="text-sm font-semibold text-slate-500 mb-1 uppercase tracking-wide">{label}</p>
      <p className="text-slate-900 whitespace-pre-wrap leading-relaxed bg-slate-50/50 p-3 rounded-lg border border-slate-100">{value}</p>
    </div>
  );
}
