import { useParams, Link } from "wouter";
import { useGetSubmission, useGetCase } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowLeft, CheckCircle, AlertTriangle, Lightbulb } from "lucide-react";
import { formatDate } from "@/lib/utils";

export default function SubmissionDetail() {
  const { id } = useParams();
  const { data: result, isLoading } = useGetSubmission(parseInt(id || "0"));
  const { data: clinicalCase } = useGetCase(result?.caseId || 0, { query: { enabled: !!result?.caseId } });

  if (isLoading) return <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!result) return <div>Result not found</div>;

  const getScoreColor = (pct: number) => {
    if (pct >= 80) return "text-green-600";
    if (pct >= 50) return "text-yellow-600";
    return "text-red-600";
  };
  const getScoreBg = (pct: number) => {
    if (pct >= 80) return "bg-green-500";
    if (pct >= 50) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto page-enter">
      <div className="flex items-center gap-4">
        <Link href="/results">
          <Button variant="outline" size="icon" className="rounded-full h-10 w-10"><ArrowLeft className="h-5 w-5"/></Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Baholash Natijasi</h1>
          <p className="text-slate-500">{clinicalCase?.title} • {formatDate(result.submittedAt)}</p>
        </div>
      </div>

      <Card className="bg-gradient-to-br from-slate-900 to-slate-800 text-white overflow-hidden border-none shadow-2xl relative">
        <div className="absolute top-0 right-0 p-12 opacity-10 pointer-events-none">
          <CheckCircle className="w-64 h-64" />
        </div>
        <CardContent className="p-8 md:p-12 relative z-10">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="relative shrink-0">
              <svg className="w-48 h-48 transform -rotate-90">
                <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-slate-700" />
                <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="12" fill="transparent"
                  strokeDasharray={553} strokeDashoffset={553 - (553 * result.percentage) / 100}
                  className={getScoreColor(result.percentage).replace('text-', 'text-')} 
                  style={{ color: result.percentage >= 80 ? '#22c55e' : result.percentage >= 50 ? '#eab308' : '#ef4444' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-5xl font-black">{result.percentage}%</span>
                <span className="text-sm text-slate-400 mt-1">{result.totalScore} / {result.maxScore} ball</span>
              </div>
            </div>
            
            <div className="flex-1 space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-2">AI Xulosasi</h3>
                <p className="text-slate-300 leading-relaxed text-lg">{result.overallFeedback}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-red-100 bg-red-50/50">
          <CardHeader>
            <CardTitle className="text-red-800 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" /> Asosiy Xatolar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {result.mistakeAreas.map((m, i) => (
                <li key={i} className="flex gap-3 text-red-900/80">
                  <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-red-400 shrink-0" />
                  <span>{m}</span>
                </li>
              ))}
              {result.mistakeAreas.length === 0 && <p className="text-green-600">Xatolar aniqlanmadi, ajoyib natija!</p>}
            </ul>
          </CardContent>
        </Card>

        <Card className="border-blue-100 bg-blue-50/50">
          <CardHeader>
            <CardTitle className="text-blue-800 flex items-center gap-2">
              <Lightbulb className="h-5 w-5" /> Tavsiyalar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {result.recommendations.map((r, i) => (
                <li key={i} className="flex gap-3 text-blue-900/80">
                  <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                  <span>{r}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Dorilar tahlili</h2>
        <div className="space-y-4">
          {result.drugEvaluations.map((evalDrug, i) => {
            const totalDrugScore = evalDrug.drugSelectionScore + evalDrug.doseScore + evalDrug.combinationScore + evalDrug.effectivenessScore + evalDrug.safetyScore;
            return (
              <Card key={i} className="overflow-hidden">
                <div className="bg-slate-50 p-4 border-b border-slate-100 flex justify-between items-center">
                  <h4 className="font-bold text-lg text-slate-900">{evalDrug.drugName}</h4>
                  <span className="font-semibold text-primary">{totalDrugScore.toFixed(1)} ball</span>
                </div>
                <CardContent className="p-0">
                  <div className="grid grid-cols-2 md:grid-cols-5 divide-x divide-y md:divide-y-0 divide-slate-100">
                    <ScoreBox label="Tanlov" score={evalDrug.drugSelectionScore} max={10} />
                    <ScoreBox label="Doza" score={evalDrug.doseScore} max={10} />
                    <ScoreBox label="Kombinatsiya" score={evalDrug.combinationScore} max={10} />
                    <ScoreBox label="Samara" score={evalDrug.effectivenessScore} max={10} />
                    <ScoreBox label="Xavfsizlik" score={evalDrug.safetyScore} max={10} />
                  </div>
                  <div className="p-4 bg-white">
                    <p className="text-sm text-slate-600"><span className="font-semibold text-slate-900">Izoh:</span> {evalDrug.feedback}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function ScoreBox({ label, score, max }: { label: string, score: number, max: number }) {
  const pct = (score / max) * 100;
  return (
    <div className="p-4 text-center">
      <p className="text-xs text-slate-500 uppercase font-semibold mb-2">{label}</p>
      <div className="text-xl font-bold text-slate-800 mb-2">{score}</div>
      <Progress value={pct} indicatorColor={pct >= 80 ? 'bg-green-500' : pct >= 50 ? 'bg-yellow-500' : 'bg-red-500'} />
    </div>
  );
}
