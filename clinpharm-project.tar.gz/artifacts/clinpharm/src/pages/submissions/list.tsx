import { useAuth } from "@/hooks/use-auth";
import { useListSubmissions } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";
import { FileText } from "lucide-react";

export default function SubmissionsList() {
  const { user } = useAuth();
  // Admin/Teacher see all, Student sees own
  const params = user?.role === 'student' ? { studentId: user.id } : {};
  const { data: submissions, isLoading } = useListSubmissions(params);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900">
          {user?.role === 'student' ? 'Natijalarim' : 'Barcha Natijalar'}
        </h1>
        <p className="text-slate-500 mt-1">Yechilgan keyslar tahlili</p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1,2,3].map(i => <div key={i} className="h-20 bg-slate-200 rounded-xl animate-pulse"/>)}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="p-4 font-semibold">Keys</th>
                  {user?.role !== 'student' && <th className="p-4 font-semibold">Talaba</th>}
                  <th className="p-4 font-semibold">Sana</th>
                  <th className="p-4 font-semibold">Natija</th>
                  <th className="p-4 font-semibold text-right">Amal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {submissions?.map((sub) => (
                  <tr key={sub.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-lg text-primary">
                          <FileText className="h-4 w-4" />
                        </div>
                        <span className="font-semibold text-slate-900">{sub.caseTitle}</span>
                      </div>
                    </td>
                    {user?.role !== 'student' && <td className="p-4">{sub.studentName}</td>}
                    <td className="p-4 text-slate-500">{formatDate(sub.submittedAt)}</td>
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        sub.percentage >= 80 ? 'bg-green-100 text-green-700' :
                        sub.percentage >= 50 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                      }`}>
                        {sub.percentage}%
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <Link href={`/results/${sub.id}`}>
                        <Button variant="ghost" size="sm">Tahlil</Button>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {submissions?.length === 0 && (
              <div className="p-12 text-center text-slate-500">Hech qanday natija yo'q.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
