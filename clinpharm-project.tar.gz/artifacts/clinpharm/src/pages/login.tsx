import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Stethoscope } from "lucide-react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login.mutate({ data: { email, password } });
  };

  return (
    <div className="min-h-screen w-full flex relative bg-slate-50">
      {/* Background Image Area */}
      <div className="hidden lg:block w-1/2 relative bg-primary/10">
        <img 
          src={`${import.meta.env.BASE_URL}images/auth-bg.png`} 
          alt="Medical background" 
          className="absolute inset-0 w-full h-full object-cover mix-blend-multiply opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-center p-16 text-slate-800">
          <div className="bg-white/80 backdrop-blur-md p-8 rounded-3xl inline-block max-w-md shadow-xl border border-white/50">
            <Stethoscope className="h-12 w-12 text-primary mb-6" />
            <h1 className="text-4xl font-display font-bold mb-4">ClinPharm AI Trainer</h1>
            <p className="text-lg text-slate-600">
              Klinik farmakologiyani o'rganish va amaliyotda qo'llash uchun innovatsion platforma.
            </p>
          </div>
        </div>
      </div>

      {/* Form Area */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <Card className="w-full max-w-md p-8 border-none shadow-2xl bg-white/90 backdrop-blur-sm">
          <div className="text-center mb-8">
            <div className="bg-primary/10 p-3 rounded-2xl inline-block mb-4 lg:hidden">
              <Stethoscope className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-3xl font-display font-bold text-slate-900">Tizimga kirish</h2>
            <p className="text-slate-500 mt-2">Ma'lumotlaringizni kiriting</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email">Email manzil</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="admin@clinpharm.uz"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-12"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Parol</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-12"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-lg" 
              isLoading={login.isPending}
            >
              Kirish
            </Button>
          </form>

          <p className="text-center mt-8 text-sm text-slate-600">
            Hisobingiz yo'qmi?{' '}
            <Link href="/register" className="font-semibold text-primary hover:underline">
              Ro'yxatdan o'tish
            </Link>
          </p>
        </Card>
      </div>
    </div>
  );
}
