import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useGetAnalyticsOverview, useListCases, useListSubmissions } from "@workspace/api-client-react";
import { Activity, BookOpen, CheckCircle, Users, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900">Xush kelibsiz, {user?.name}</h1>
        <p className="text-slate-500 mt-2">Bugun nimalarni o'rganamiz?</p>
      </div>

      {user?.role === 'admin' && <AdminDashboard />}
      {user?.role === 'teacher' && <TeacherDashboard />}
      {user?.role === 'student' && <StudentDashboard />}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, colorClass }: any) {
  return (
    <Card>
      <CardContent className="p-6 flex items-center gap-4">
        <div className={`p-4 rounded-2xl ${colorClass}`}>
          <Icon className="h-6 w-6" />
        </div>
        <div>
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <h4 className="text-3xl font-bold text-slate-900">{value}</h4>
        </div>
      </CardContent>
    </Card>
  );
}

function AdminDashboard() {
  const { data: analytics, isLoading } = useGetAnalyticsOverview();

  if (isLoading) return <div className="animate-pulse flex gap-4"><div className="h-32 w-1/4 bg-slate-200 rounded-2xl" /></div>;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Jami Talabalar" value={analytics?.totalStudents || 0} icon={Users} colorClass="bg-blue-100 text-blue-600" />
        <StatCard title="Jami Keyslar" value={analytics?.totalCases || 0} icon={BookOpen} colorClass="bg-indigo-100 text-indigo-600" />
        <StatCard title="Urinishlar" value={analytics?.totalSubmissions || 0} icon={Activity} colorClass="bg-teal-100 text-teal-600" />
        <StatCard title="O'rtacha Ball" value={`${analytics?.averageScore?.toFixed(1) || 0}%`} icon={CheckCircle} colorClass="bg-emerald-100 text-emerald-600" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Eng ko'p yo'l qo'yiladigan xatolar</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {analytics?.topMistakeAreas?.map((mistake, i) => (
              <li key={i} className="flex items-center gap-3 bg-slate-50 p-3 rounded-lg">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-xs font-bold">{i+1}</span>
                <span className="text-slate-700">{mistake}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

function TeacherDashboard() {
  const { data: analytics } = useGetAnalyticsOverview();
  const { data: cases } = useListCases();

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Yaratilgan Keyslar" value={cases?.length || 0} icon={BookOpen} colorClass="bg-blue-100 text-blue-600" />
        <StatCard title="Tekshirilganlar" value={analytics?.totalSubmissions || 0} icon={Activity} colorClass="bg-indigo-100 text-indigo-600" />
        <StatCard title="O'rtacha Ball" value={`${analytics?.averageScore?.toFixed(1) || 0}%`} icon={CheckCircle} colorClass="bg-emerald-100 text-emerald-600" />
      </div>

      <div className="flex gap-4">
        <Link href="/teacher/cases/new">
          <Button size="lg" className="gap-2"><BookOpen className="h-5 w-5"/> Yangi keys yaratish</Button>
        </Link>
        <Link href="/results">
          <Button size="lg" variant="outline" className="gap-2"><Users className="h-5 w-5"/> Natijalarni ko'rish</Button>
        </Link>
      </div>
    </div>
  );
}

function StudentDashboard() {
  const { user } = useAuth();
  const { data: cases } = useListCases();
  const { data: submissions } = useListSubmissions({ studentId: user?.id });

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-br from-primary to-primary/80 text-white border-none shadow-lg shadow-primary/20">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold mb-2">Amaliyotni boshlang</h3>
            <p className="text-primary-foreground/80 mb-6">Yangi klinik holatlarni o'rganing va bilimingizni sinab ko'ring.</p>
            <Link href="/cases">
              <Button variant="secondary" className="w-full sm:w-auto text-primary gap-2">
                Keyslarga o'tish <ArrowRight className="h-4 w-4"/>
              </Button>
            </Link>
          </CardContent>
        </Card>

        <StatCard title="Sizning yechimlaringiz" value={submissions?.length || 0} icon={CheckCircle} colorClass="bg-primary/20 text-primary" />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">So'nggi natijalar</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {submissions?.slice(0, 3).map(sub => (
            <Card key={sub.id}>
              <CardContent className="p-5">
                <p className="font-semibold text-slate-900 mb-1">{sub.caseTitle}</p>
                <div className="flex items-center justify-between mt-4">
                  <span className="text-sm text-slate-500">{new Date(sub.submittedAt).toLocaleDateString()}</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                    sub.percentage >= 80 ? 'bg-green-100 text-green-700' :
                    sub.percentage >= 50 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {sub.percentage}%
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
          {!submissions?.length && (
            <p className="text-slate-500 col-span-full">Hali hech qanday keys yechilmagan.</p>
          )}
        </div>
      </div>
    </div>
  );
}
