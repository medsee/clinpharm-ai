import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { hashPassword, generateToken, createSession, deleteSession, requireAuth } from "../lib/auth.js";
import { RegisterBody, LoginBody } from "@workspace/api-zod";

const router = Router();

router.post("/register", async (req, res) => {
  try {
    const body = RegisterBody.parse(req.body);
    const existing = await db.select().from(usersTable).where(eq(usersTable.email, body.email)).limit(1);
    if (existing[0]) {
      res.status(400).json({ error: "Bu email allaqachon ro'yxatdan o'tgan" });
      return;
    }
    const [user] = await db.insert(usersTable).values({
      name: body.name,
      email: body.email,
      passwordHash: hashPassword(body.password),
      role: body.role as any,
    }).returning();
    const token = generateToken(user.id);
    createSession(token, user.id);
    res.status(201).json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role, createdAt: user.createdAt.toISOString() },
      token,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || "Xato" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const body = LoginBody.parse(req.body);
    const [user] = await db.select().from(usersTable).where(eq(usersTable.email, body.email)).limit(1);
    if (!user || user.passwordHash !== hashPassword(body.password)) {
      res.status(401).json({ error: "Email yoki parol noto'g'ri" });
      return;
    }
    const token = generateToken(user.id);
    createSession(token, user.id);
    res.json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role, createdAt: user.createdAt.toISOString() },
      token,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || "Xato" });
  }
});

router.post("/logout", requireAuth, (req, res) => {
  const token = (req as any).token;
  deleteSession(token);
  res.json({ message: "Muvaffaqiyatli chiqildi" });
});

router.get("/me", requireAuth, (req, res) => {
  const user = (req as any).user;
  res.json({ id: user.id, name: user.name, email: user.email, role: user.role, createdAt: user.createdAt.toISOString() });
});

export default router;
