import { Router } from "express";
import { db, casesTable, submissionsTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";

const router = Router();

function evaluateDrugAnswer(drug: any, criteria: any): any {
  const correctDrug = (criteria.correctDrug || "").toLowerCase();
  const submittedDrug = (drug.drugName || "").toLowerCase();
  
  const drugSelectionScore = submittedDrug && correctDrug && (
    submittedDrug.includes(correctDrug) || correctDrug.includes(submittedDrug)
  ) ? criteria.drugSelectionWeight * 10 : 0;
  
  const correctDose = (criteria.correctDose || "");
  const submittedDose = (drug.dose || "");
  const doseScore = submittedDose && correctDose && submittedDose === correctDose
    ? criteria.doseCorrectWeight * 10 : (submittedDose ? criteria.doseCorrectWeight * 5 : 0);

  const combinationScore = criteria.interactionsWeight * 7;
  const effectivenessScore = criteria.durationWeight * 8;
  const safetyScore = criteria.safetyWeight * 8;

  let feedback = "";
  if (drugSelectionScore === 0) {
    feedback = `"${drug.drugName}" dori tanlash to'g'ri emas. To'g'ri dori: ${criteria.correctDrug || "ko'rsatilmagan"}. `;
  } else {
    feedback = `Dori tanlov to'g'ri. `;
  }
  if (doseScore < criteria.doseCorrectWeight * 10) {
    feedback += `Doza: "${drug.dose}" - to'g'ri doza: ${criteria.correctDose || "ko'rsatilmagan"}. `;
  }
  if (!drug.duration) {
    feedback += `Davolash davomiyligi ko'rsatilmagan (to'g'ri: ${criteria.correctDuration || "ko'rsatilmagan"}). `;
  }

  return {
    drugName: drug.drugName,
    drugSelectionScore,
    doseScore,
    combinationScore,
    effectivenessScore,
    safetyScore,
    feedback,
  };
}

function generateFeedback(drugs: any[], criteria: any, percentage: number, monitoringPlan: string): { feedback: string; mistakes: string[]; recommendations: string[] } {
  const mistakes: string[] = [];
  const recommendations: string[] = [];

  if (percentage < 50) {
    mistakes.push("Dori tanlashda jiddiy xatolar mavjud");
    recommendations.push("Klinik farmakologiya asoslarini qayta o'rganish tavsiya etiladi");
    recommendations.push("Kasallikning patofiziyologiyasini chuqurroq o'rganing");
  } else if (percentage < 70) {
    mistakes.push("Doza va davomiylik belgilashda xatolar mavjud");
    recommendations.push("Dorilarning farmakokinetikas bo'yicha ma'lumotni yangilang");
  } else if (percentage < 85) {
    mistakes.push("Monitoring rejasi yetarli emas");
    recommendations.push("Terapiya monitoringi bo'yicha bilimlarni mustahkamlang");
  }

  if (!monitoringPlan) {
    mistakes.push("Monitoring rejasi ko'rsatilmagan");
    recommendations.push("Terapiyaning samaradorligi va xavfsizligini baholash rejasini tuzing");
  }

  const feedback = percentage >= 85
    ? "Ajoyib ish! Farmakoterapiya to'g'ri tanlangan va to'liq asoslangan."
    : percentage >= 70
    ? "Yaxshi harakat. Ba'zi jihatlarda qo'shimcha o'rganish tavsiya etiladi."
    : percentage >= 50
    ? "O'rtacha natija. Asosiy xatolarni tahlil qilib, mavzuni qayta o'rganing."
    : "Dori tanlash va dozalashda jiddiy xatolar mavjud. Iltimos, o'qituvchi bilan maslahatlashing.";

  return { feedback, mistakes, recommendations };
}

router.post("/cases/:id/submit", requireAuth, async (req, res) => {
  try {
    const user = (req as any).user;
    const caseId = parseInt(req.params.id);
    const { drugs, monitoringPlan, sideEffectPrevention, clinicalRationale } = req.body;

    const [c] = await db.select().from(casesTable).where(eq(casesTable.id, caseId)).limit(1);
    if (!c) {
      res.status(404).json({ error: "Keys topilmadi" });
      return;
    }

    const criteria = c.evaluationCriteria as any;
    const drugEvaluations = (drugs || []).map((drug: any) => evaluateDrugAnswer(drug, criteria));

    const totalScore = drugEvaluations.reduce((sum: number, d: any) => {
      return sum + d.drugSelectionScore + d.doseScore + d.combinationScore + d.effectivenessScore + d.safetyScore;
    }, 0);

    const maxScore = 100;
    const percentage = Math.min(100, Math.round((totalScore / maxScore) * 100));

    const { feedback, mistakes, recommendations } = generateFeedback(drugs, criteria, percentage, monitoringPlan);

    const [submission] = await db.insert(submissionsTable).values({
      caseId,
      studentId: user.id,
      answers: { drugs, monitoringPlan, sideEffectPrevention, clinicalRationale },
      totalScore,
      maxScore,
      percentage,
      drugEvaluations,
      overallFeedback: feedback,
      mistakeAreas: mistakes,
      recommendations,
    }).returning();

    res.json({
      id: submission.id,
      caseId: submission.caseId,
      studentId: submission.studentId,
      totalScore: submission.totalScore,
      maxScore: submission.maxScore,
      percentage: submission.percentage,
      drugEvaluations: submission.drugEvaluations,
      overallFeedback: submission.overallFeedback,
      mistakeAreas: submission.mistakeAreas,
      recommendations: submission.recommendations,
      submittedAt: submission.submittedAt.toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/", requireAuth, async (req, res) => {
  try {
    const user = (req as any).user;
    let submissions = await db.select().from(submissionsTable);

    if (user.role === "student") {
      submissions = submissions.filter(s => s.studentId === user.id);
    } else if (req.query.studentId) {
      submissions = submissions.filter(s => s.studentId === parseInt(req.query.studentId as string));
    }
    if (req.query.caseId) {
      submissions = submissions.filter(s => s.caseId === parseInt(req.query.caseId as string));
    }

    const cases = await db.select().from(casesTable);
    const users = await db.select().from(usersTable);

    res.json(submissions.map(s => {
      const c = cases.find(x => x.id === s.caseId);
      const u = users.find(x => x.id === s.studentId);
      return {
        id: s.id,
        caseId: s.caseId,
        caseTitle: c?.title || "Noma'lum",
        studentId: s.studentId,
        studentName: u?.name || "Noma'lum",
        percentage: s.percentage,
        submittedAt: s.submittedAt.toISOString(),
      };
    }));
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [s] = await db.select().from(submissionsTable).where(eq(submissionsTable.id, id)).limit(1);
    if (!s) {
      res.status(404).json({ error: "Topshiriq topilmadi" });
      return;
    }
    res.json({
      id: s.id,
      caseId: s.caseId,
      studentId: s.studentId,
      totalScore: s.totalScore,
      maxScore: s.maxScore,
      percentage: s.percentage,
      drugEvaluations: s.drugEvaluations,
      overallFeedback: s.overallFeedback,
      mistakeAreas: s.mistakeAreas,
      recommendations: s.recommendations,
      submittedAt: s.submittedAt.toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
