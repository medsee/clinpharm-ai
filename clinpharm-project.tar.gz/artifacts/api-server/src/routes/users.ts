import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const user = (req as any).user;
    if (user.role !== "admin") {
      res.status(403).json({ error: "Ruxsat yo'q" });
      return;
    }
    const users = await db.select().from(usersTable);
    res.json(users.map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      createdAt: u.createdAt.toISOString(),
    })));
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.put("/:id", requireAuth, async (req, res) => {
  try {
    const currentUser = (req as any).user;
    if (currentUser.role !== "admin") {
      res.status(403).json({ error: "Ruxsat yo'q" });
      return;
    }
    const id = parseInt(req.params.id);
    const { role, name } = req.body;
    const updates: any = {};
    if (role) updates.role = role;
    if (name) updates.name = name;
    const [u] = await db.update(usersTable).set(updates).where(eq(usersTable.id, id)).returning();
    if (!u) {
      res.status(404).json({ error: "Foydalanuvchi topilmadi" });
      return;
    }
    res.json({ id: u.id, name: u.name, email: u.email, role: u.role, createdAt: u.createdAt.toISOString() });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
