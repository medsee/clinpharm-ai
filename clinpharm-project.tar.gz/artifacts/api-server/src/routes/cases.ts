import { Router } from "express";
import { db, casesTable, submissionsTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";

const router = Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const cases = await db.select().from(casesTable);
    const specialty = req.query.specialty as string;
    const difficulty = req.query.difficulty as string;
    let filtered = cases;
    if (specialty) filtered = filtered.filter(c => c.specialty === specialty);
    if (difficulty) filtered = filtered.filter(c => c.difficulty === difficulty);
    res.json(filtered.map(c => ({
      id: c.id,
      title: c.title,
      specialty: c.specialty,
      topic: c.topic,
      difficulty: c.difficulty,
      createdAt: c.createdAt.toISOString(),
    })));
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/", requireAuth, async (req, res) => {
  try {
    const user = (req as any).user;
    if (!["teacher", "admin"].includes(user.role)) {
      res.status(403).json({ error: "Ruxsat yo'q" });
      return;
    }
    const { title, specialty, topic, difficulty, patientInfo, evaluationCriteria } = req.body;
    const [c] = await db.insert(casesTable).values({
      title,
      specialty,
      topic,
      difficulty,
      patientInfo,
      evaluationCriteria,
      createdBy: user.id,
    }).returning();
    res.status(201).json({
      id: c.id,
      title: c.title,
      specialty: c.specialty,
      topic: c.topic,
      difficulty: c.difficulty,
      patientInfo: c.patientInfo,
      evaluationCriteria: c.evaluationCriteria,
      createdBy: c.createdBy,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get("/:id", requireAuth, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [c] = await db.select().from(casesTable).where(eq(casesTable.id, id)).limit(1);
    if (!c) {
      res.status(404).json({ error: "Keys topilmadi" });
      return;
    }
    res.json({
      id: c.id,
      title: c.title,
      specialty: c.specialty,
      topic: c.topic,
      difficulty: c.difficulty,
      patientInfo: c.patientInfo,
      evaluationCriteria: c.evaluationCriteria,
      createdBy: c.createdBy,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.put("/:id", requireAuth, async (req, res) => {
  try {
    const user = (req as any).user;
    if (!["teacher", "admin"].includes(user.role)) {
      res.status(403).json({ error: "Ruxsat yo'q" });
      return;
    }
    const id = parseInt(req.params.id);
    const { title, specialty, topic, difficulty, patientInfo, evaluationCriteria } = req.body;
    const [c] = await db.update(casesTable)
      .set({ title, specialty, topic, difficulty, patientInfo, evaluationCriteria, updatedAt: new Date() })
      .where(eq(casesTable.id, id))
      .returning();
    if (!c) {
      res.status(404).json({ error: "Keys topilmadi" });
      return;
    }
    res.json({
      id: c.id,
      title: c.title,
      specialty: c.specialty,
      topic: c.topic,
      difficulty: c.difficulty,
      patientInfo: c.patientInfo,
      evaluationCriteria: c.evaluationCriteria,
      createdBy: c.createdBy,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete("/:id", requireAuth, async (req, res) => {
  try {
    const user = (req as any).user;
    if (!["teacher", "admin"].includes(user.role)) {
      res.status(403).json({ error: "Ruxsat yo'q" });
      return;
    }
    const id = parseInt(req.params.id);
    await db.delete(casesTable).where(eq(casesTable.id, id));
    res.json({ message: "Keys o'chirildi" });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
