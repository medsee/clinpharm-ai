import { Router } from "express";
import { db, casesTable, submissionsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth.js";

const router = Router();

router.get("/overview", requireAuth, async (req, res) => {
  try {
    const user = (req as any).user;
    if (!["teacher", "admin"].includes(user.role)) {
      res.status(403).json({ error: "Ruxsat yo'q" });
      return;
    }
    const users = await db.select().from(usersTable);
    const cases = await db.select().from(casesTable);
    const submissions = await db.select().from(submissionsTable);

    const students = users.filter(u => u.role === "student");
    const avgScore = submissions.length > 0
      ? submissions.reduce((s, sub) => s + sub.percentage, 0) / submissions.length
      : 0;

    const mistakeCounts: Record<string, number> = {};
    submissions.forEach(sub => {
      const areas = (sub.mistakeAreas as string[]) || [];
      areas.forEach(area => {
        mistakeCounts[area] = (mistakeCounts[area] || 0) + 1;
      });
    });
    const topMistakeAreas = Object.entries(mistakeCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([area]) => area);

    const scoreDistribution = [
      { range: "0-49%", count: submissions.filter(s => s.percentage < 50).length },
      { range: "50-69%", count: submissions.filter(s => s.percentage >= 50 && s.percentage < 70).length },
      { range: "70-84%", count: submissions.filter(s => s.percentage >= 70 && s.percentage < 85).length },
      { range: "85-100%", count: submissions.filter(s => s.percentage >= 85).length },
    ];

    res.json({
      totalStudents: students.length,
      totalCases: cases.length,
      totalSubmissions: submissions.length,
      averageScore: Math.round(avgScore * 10) / 10,
      topMistakeAreas,
      scoreDistribution,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/student/:id", requireAuth, async (req, res) => {
  try {
    const currentUser = (req as any).user;
    const studentId = parseInt(req.params.id);
    if (currentUser.role === "student" && currentUser.id !== studentId) {
      res.status(403).json({ error: "Ruxsat yo'q" });
      return;
    }

    const [student] = await db.select().from(usersTable).where(eq(usersTable.id, studentId)).limit(1);
    if (!student) {
      res.status(404).json({ error: "Talaba topilmadi" });
      return;
    }

    const submissions = await db.select().from(submissionsTable).where(eq(submissionsTable.studentId, studentId));
    const cases = await db.select().from(casesTable);
    const users = await db.select().from(usersTable);

    const avgScore = submissions.length > 0
      ? submissions.reduce((s, sub) => s + sub.percentage, 0) / submissions.length
      : 0;

    const mistakeCounts: Record<string, number> = {};
    const goodAreas: Record<string, number> = {};
    submissions.forEach(sub => {
      const areas = (sub.mistakeAreas as string[]) || [];
      areas.forEach(area => { mistakeCounts[area] = (mistakeCounts[area] || 0) + 1; });
      if (sub.percentage >= 85) {
        const c = cases.find(x => x.id === sub.caseId);
        if (c) { goodAreas[c.specialty] = (goodAreas[c.specialty] || 0) + 1; }
      }
    });

    const weakAreas = Object.entries(mistakeCounts).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([a]) => a);
    const strongAreas = Object.entries(goodAreas).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([a]) => a);

    const history = submissions.map(s => {
      const c = cases.find(x => x.id === s.caseId);
      const u = users.find(x => x.id === s.studentId);
      return {
        id: s.id,
        caseId: s.caseId,
        caseTitle: c?.title || "Noma'lum",
        studentId: s.studentId,
        studentName: u?.name || "Noma'lum",
        percentage: s.percentage,
        submittedAt: s.submittedAt.toISOString(),
      };
    });

    res.json({
      studentId: student.id,
      studentName: student.name,
      totalSubmissions: submissions.length,
      averageScore: Math.round(avgScore * 10) / 10,
      submissionHistory: history,
      weakAreas,
      strongAreas,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
