import { Router } from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import casesRouter from "./cases.js";
import submissionsRouter from "./submissions.js";
import usersRouter from "./users.js";
import analyticsRouter from "./analytics.js";

const router = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/cases", casesRouter);
router.use("/submissions", submissionsRouter);
router.use("/cases", submissionsRouter);
router.use("/users", usersRouter);
router.use("/analytics", analyticsRouter);

export default router;
