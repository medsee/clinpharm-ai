import { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password + "clinpharm_salt_2025").digest("hex");
}

export function generateToken(userId: number): string {
  return crypto.createHash("sha256").update(`${userId}_${Date.now()}_clinpharm_secret`).digest("hex");
}

const sessions: Map<string, number> = new Map();

export function createSession(token: string, userId: number) {
  sessions.set(token, userId);
}

export function getSessionUserId(token: string): number | undefined {
  return sessions.get(token);
}

export function deleteSession(token: string) {
  sessions.delete(token);
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Avtorizatsiya talab qilinadi" });
    return;
  }
  const token = authHeader.slice(7);
  const userId = getSessionUserId(token);
  if (!userId) {
    res.status(401).json({ error: "Noto'g'ri yoki muddati o'tgan token" });
    return;
  }
  const user = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  if (!user[0]) {
    res.status(401).json({ error: "Foydalanuvchi topilmadi" });
    return;
  }
  (req as any).user = user[0];
  (req as any).token = token;
  next();
}

export async function requireRole(...roles: string[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    await requireAuth(req, res, async () => {
      const user = (req as any).user;
      if (!roles.includes(user.role)) {
        res.status(403).json({ error: "Ruxsat yo'q" });
        return;
      }
      next();
    });
  };
}
