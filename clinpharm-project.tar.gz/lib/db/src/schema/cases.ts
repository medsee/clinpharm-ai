import { pgTable, serial, text, integer, timestamp, pgEnum, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const difficultyEnum = pgEnum("difficulty", ["easy", "medium", "hard"]);
export const genderEnum = pgEnum("gender", ["male", "female"]);
export const organStatusEnum = pgEnum("organ_status", ["normal", "mild_impairment", "severe_impairment"]);
export const severityEnum = pgEnum("severity", ["mild", "moderate", "severe"]);

export const casesTable = pgTable("cases", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  specialty: text("specialty").notNull(),
  topic: text("topic").notNull(),
  difficulty: difficultyEnum("difficulty").notNull().default("medium"),
  patientInfo: json("patient_info").notNull(),
  evaluationCriteria: json("evaluation_criteria").notNull(),
  createdBy: integer("created_by").references(() => usersTable.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCaseSchema = createInsertSchema(casesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCase = z.infer<typeof insertCaseSchema>;
export type Case = typeof casesTable.$inferSelect;
