import { pgTable, serial, integer, json, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { casesTable } from "./cases";

export const submissionsTable = pgTable("submissions", {
  id: serial("id").primaryKey(),
  caseId: integer("case_id").references(() => casesTable.id).notNull(),
  studentId: integer("student_id").references(() => usersTable.id).notNull(),
  answers: json("answers").notNull(),
  totalScore: real("total_score").notNull().default(0),
  maxScore: real("max_score").notNull().default(100),
  percentage: real("percentage").notNull().default(0),
  drugEvaluations: json("drug_evaluations").notNull().default([]),
  overallFeedback: json("overall_feedback").notNull().default("{}"),
  mistakeAreas: json("mistake_areas").notNull().default([]),
  recommendations: json("recommendations").notNull().default([]),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
});

export const insertSubmissionSchema = createInsertSchema(submissionsTable).omit({ id: true, submittedAt: true });
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Submission = typeof submissionsTable.$inferSelect;
