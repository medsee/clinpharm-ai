import { db, usersTable, casesTable } from "@workspace/db";
import crypto from "crypto";

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password + "clinpharm_salt_2025").digest("hex");
}

async function seed() {
  console.log("Seeding database...");

  const existingAdmin = await db.select().from(usersTable);
  if (existingAdmin.length > 0) {
    console.log("Database already seeded, skipping.");
    process.exit(0);
  }

  const [admin] = await db.insert(usersTable).values({
    name: "Admin",
    email: "admin@clinpharm.uz",
    passwordHash: hashPassword("admin123"),
    role: "admin",
  }).returning();

  const [teacher] = await db.insert(usersTable).values({
    name: "Dr. Aziza Karimova",
    email: "teacher@clinpharm.uz",
    passwordHash: hashPassword("teacher123"),
    role: "teacher",
  }).returning();

  await db.insert(usersTable).values({
    name: "Alisher Toshmatov",
    email: "student@clinpharm.uz",
    passwordHash: hashPassword("student123"),
    role: "student",
  });

  await db.insert(casesTable).values([
    {
      title: "O'tkir o'ng tomonlama pastki bo'lak pnevmoniyasi, o'rta og'ir kechishi",
      specialty: "Pulmonologiya",
      topic: "Pnevmoniya",
      difficulty: "medium",
      createdBy: teacher.id,
      patientInfo: {
        age: 52,
        gender: "female",
        mainComplaint: "Yo'tal, nafas qisilishi, isitma 39°C, yon tomonda og'riq",
        anamnesis: "5 kun oldin sovuqlik, asta-sekin og'irlashgan. Tibbiy muassasaga murojaat qilmagan.",
        comorbidities: "Surunkali pielonefrit, qo'zg'alish davri. Surunkali temir yetishmovchiligi anemiyasi, II daraja. Homiladorlik 14 haftalik",
        isPregnant: true,
        isLactating: false,
        liverStatus: "normal",
        kidneyStatus: "mild_impairment",
        allergyHistory: "Ampicillin ga allergik reaksiya kuzatilgan (04.11.2025)",
        currentMedications: "Temir preparatlari qabul qilmoqda",
        labResults: "OAQ: leykotsitoz (12.5x10^9/L), ESR 45 mm/soat, gemoglobin 95 g/L. Biokimyo: kreatinin 110 mkm/L",
        instrumentalResults: "O'pka rentgeni: o'ng tomonda pastki bo'lak infiltratsiyasi. Puls oksimetriya: SpO2 94%",
        severityLevel: "moderate",
      },
      evaluationCriteria: {
        drugSelectionWeight: 3,
        doseCorrectWeight: 2,
        contraindicationsWeight: 2,
        interactionsWeight: 1,
        durationWeight: 1,
        monitoringWeight: 1,
        safetyWeight: 2,
        correctDrug: "Amoksisiklin/klavulanat",
        correctDose: "875/125 mg",
        correctDuration: "7-10 kun",
        correctRoute: "Og'iz orqali",
        monitoringPlan: "Harorat, nafas tezligi, SpO2 kunlik monitoring. 3 kundan keyin qayta baholash. Kreatinin nazorati.",
        correctRationale: "Homiladorlikda xavfsiz, beta-laktam antibiotiklar birinchi tanlash. Ampicillin allergiyasi bor, shuning uchun amoksisiklin/klavulanat yoki sefazolin tanlash kerak.",
      },
    },
    {
      title: "O'tkir miokard infarkti, ST elevatsiyasi bilan",
      specialty: "Kardiologiya",
      topic: "Miokard infarkti",
      difficulty: "hard",
      createdBy: teacher.id,
      patientInfo: {
        age: 65,
        gender: "male",
        mainComplaint: "Ko'krak sohasida kuchli siquvchi og'riq, 30 daqiqadan oshiq, chap qo'lga tarqaladi, nafas qisilishi, ko'ngil aynishi",
        anamnesis: "Yurak kasalligi anamnezida yo'q. Gipertoniya 10 yil. Chekuvchi. To'satdan boshlangan.",
        comorbidities: "Gipertoniya III daraja. Qandli diabet II turi, kompensatsiya davrida.",
        isPregnant: false,
        isLactating: false,
        liverStatus: "normal",
        kidneyStatus: "normal",
        allergyHistory: "Yo'q",
        currentMedications: "Amlodipim 10 mg/kun, Metformin 1000 mg x 2",
        labResults: "Troponin I: 2.5 ng/mL (norma < 0.04). KFK-MB: 45 U/L. OAQ: leykotsitoz. Glyukoza: 8.2 mmol/L",
        instrumentalResults: "EKG: II, III, aVF qo'rg'oshinlarida ST elevatsiyasi 3 mm. EXO-KG: o'ng qorincha pastki devor gipokinez.",
        severityLevel: "severe",
      },
      evaluationCriteria: {
        drugSelectionWeight: 3,
        doseCorrectWeight: 2,
        contraindicationsWeight: 3,
        interactionsWeight: 2,
        durationWeight: 1,
        monitoringWeight: 2,
        safetyWeight: 2,
        correctDrug: "Aspirin",
        correctDose: "300 mg bir martalik, keyin 75-100 mg/kun",
        correctDuration: "Muddatsiz",
        correctRoute: "Og'iz orqali",
        monitoringPlan: "Doimiy EKG monitoring, troponin dinamikasi, qon bosimi, nafas tezligi, diurez nazorati.",
        correctRationale: "STEMI tashxisida darhol dual antiplatelet terapiya: Aspirin + P2Y12 inhibitor (Klopidogrel yoki Tikagrelor). Antikoagulyant terapiya. Og'riqni kupirish.",
      },
    },
    {
      title: "Surunkali yurak etishmovchiligi, III funktsional sinf",
      specialty: "Kardiologiya",
      topic: "Yurak etishmovchiligi",
      difficulty: "easy",
      createdBy: teacher.id,
      patientInfo: {
        age: 70,
        gender: "male",
        mainComplaint: "Nafas qisilishi (kichik jismoniy yuklamada), oyoqlar shishi, tez charchash",
        anamnesis: "Miokard infarkti 5 yil oldin. Surunkali yurak etishmovchiligi tashxisi 3 yil. Davolanib kelayotgan.",
        comorbidities: "Gipertoniya. Qandli diabet II turi.",
        isPregnant: false,
        isLactating: false,
        liverStatus: "mild_impairment",
        kidneyStatus: "mild_impairment",
        allergyHistory: "Yo'q",
        currentMedications: "Furosemid 40 mg/kun",
        labResults: "OAQ: norma. Biokimyo: kreatinin 130 mkm/L, kaliy 3.8 mmol/L, BNP 850 pg/mL",
        instrumentalResults: "EXO-KG: LVEF 30%. Rentgen: o'pka shishi belgilari.",
        severityLevel: "moderate",
      },
      evaluationCriteria: {
        drugSelectionWeight: 3,
        doseCorrectWeight: 2,
        contraindicationsWeight: 2,
        interactionsWeight: 2,
        durationWeight: 1,
        monitoringWeight: 2,
        safetyWeight: 2,
        correctDrug: "Ramipril",
        correctDose: "2.5-5 mg/kun",
        correctDuration: "Muddatsiz",
        correctRoute: "Og'iz orqali",
        monitoringPlan: "Kreatinin, kaliy, qon bosimi haftalik nazorat. Yurak ritmi monitoring. Vazn kunlik nazorat.",
        correctRationale: "RAAS blokadasi (ACE inhibitor yoki ARB) + beta-bloker + diuretik + aldosteron antagonist kombinatsiyasi. Buyrak funktsiyasiga ehtiyotkorlik bilan.",
      },
    },
    {
      title: "O'tkir bronxit",
      specialty: "Pulmonologiya",
      topic: "Bronxit",
      difficulty: "easy",
      createdBy: teacher.id,
      patientInfo: {
        age: 28,
        gender: "male",
        mainComplaint: "Yo'tal (quruq, so'ngra balg'amli), isitma 37.8°C, umumiy holsizlik",
        anamnesis: "10 kun oldin ORVI bilan og'rigan. Yo'tal asta-sekin zo'raygan.",
        comorbidities: "Yo'q",
        isPregnant: false,
        isLactating: false,
        liverStatus: "normal",
        kidneyStatus: "normal",
        allergyHistory: "Yo'q",
        currentMedications: "Yo'q",
        labResults: "OAQ: leykotsitlar norma chegarasida. CRP 15 mg/L.",
        instrumentalResults: "O'pka rentgeni: infiltratsiya belgilari yo'q. Bronxit belgilari.",
        severityLevel: "mild",
      },
      evaluationCriteria: {
        drugSelectionWeight: 2,
        doseCorrectWeight: 2,
        contraindicationsWeight: 1,
        interactionsWeight: 1,
        durationWeight: 2,
        monitoringWeight: 1,
        safetyWeight: 1,
        correctDrug: "Antibiotiklar ko'rsatilmagan (viral etiology), simptomatik davolash",
        correctDose: "Ambroksol 30 mg x 3, Paratsetamol 500 mg x 3",
        correctDuration: "7-10 kun",
        correctRoute: "Og'iz orqali",
        monitoringPlan: "Harorat, yo'tal dinamikasi kuzatuvi. 5-7 kundan keyin qayta ko'rik.",
        correctRationale: "O'tkir bronxitning aksariyat hollarda viral etiologiyasi bor. Antibiotik rutiniy tayinlanmaydi. Simptomatik davolash: mukolitiklar, antipiretklar.",
      },
    },
    {
      title: "Gastroezofageal reflyuks kasalligi",
      specialty: "Gastroenterologiya",
      topic: "GERK",
      difficulty: "easy",
      createdBy: teacher.id,
      patientInfo: {
        age: 45,
        gender: "female",
        mainComplaint: "Ovqat yegandan keyin kuyish, kekirtish, goh-goh og'iz suyuqligining kislotasi",
        anamnesis: "2 yildan beri vaqti-vaqti bilan kuyish. So'nggi oyda kuchaygan. Stressli ish.",
        comorbidities: "Ortiqcha vazn",
        isPregnant: false,
        isLactating: false,
        liverStatus: "normal",
        kidneyStatus: "normal",
        allergyHistory: "Yo'q",
        currentMedications: "Yo'q",
        labResults: "OAQ: norma. H. pylori testi: manfiy.",
        instrumentalResults: "EFGDS: qizilo'ngach pastki qismida shilliq qavatning yallig'lanishi (ezofagit I daraja).",
        severityLevel: "mild",
      },
      evaluationCriteria: {
        drugSelectionWeight: 3,
        doseCorrectWeight: 2,
        contraindicationsWeight: 1,
        interactionsWeight: 1,
        durationWeight: 2,
        monitoringWeight: 1,
        safetyWeight: 1,
        correctDrug: "Omeprazol",
        correctDose: "20 mg x 2, ovqatdan 30 daqiqa oldin",
        correctDuration: "4-8 hafta",
        correctRoute: "Og'iz orqali",
        monitoringPlan: "Simptomlar dinamikasi. 4 haftadan keyin qayta baholash. Hayot tarzi o'zgarishlari.",
        correctRationale: "Proton nasos inhibitorlari GERK davolashning asosiy vositasi. Hayot tarzi o'zgarishlari (vazn kamaytirish, kech ovqat yeymaslik, bosh ko'taring uxlash).",
      },
    },
  ]);

  console.log("Database seeded successfully!");
  console.log("Admin: admin@clinpharm.uz / admin123");
  console.log("Teacher: teacher@clinpharm.uz / teacher123");
  console.log("Student: student@clinpharm.uz / student123");
  process.exit(0);
}

seed().catch(console.error);
